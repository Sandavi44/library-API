package lk.ac.mrt.fit.library_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
